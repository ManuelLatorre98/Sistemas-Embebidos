/* avr specific */

/* Not useful so far */

#define UART_FIFO_SIZE	1
struct uart_csreg {	/* avr does not use this so far */
	char c;
};


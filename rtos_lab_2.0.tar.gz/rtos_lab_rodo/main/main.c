#include <xinu.h>
#include <avr/interrupt.h>

int main(void)
{
	return 0;
}
